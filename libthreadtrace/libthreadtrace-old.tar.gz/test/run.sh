#!/bin/sh

LD_PRELOAD=/home/myron/Documents/2013W/cpsc410/project/threadtrace/libthreadtrace.so
./"$1"
