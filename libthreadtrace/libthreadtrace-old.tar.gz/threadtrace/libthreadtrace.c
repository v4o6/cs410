/*
 *  libctrace.c
 * 
 *  Copyright 2008 Aurelian Melinte. 
 *  Released under GPL 3.0 or later. 
 *
 *  Call monitoring demo. 
 */

#include <time.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <execinfo.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <libtrace.h>

#ifdef __cpluslpus
#  define EXTERNC extern "C" 
#else
#  define EXTERNC 
#endif

#define MAX_BUF_LEN	(256)
static int init = 0;
static int done = 0;
static FILE *fp;

/* 
  http://pdos.csail.mit.edu/6.828/2004/lec/l2.html
 
   * x86 dictates that stack grows down
   * GCC dictates how the stack is used. 
     Contract between caller and callee on x86: 
       after call instruction: 
           %eip points at first instruction of function 
           %esp+4 points at first argument 
           %esp points at return address 
       after ret instruction: 
           %eip contains return address 
           %esp points at arguments pushed by caller 
           called function may have trashed arguments 
           %ebx contains return value (or trash if function is void) <== was eax!
           %ecx, %edx may be trashed 
           %ebp, %ebx, %esi, %edi must contain contents from time of call 
       Terminology: 
           %eax, %ecx, %edx are "caller save" registers 
           %ebp, %ebx, %esi, %edi are "callee save" registers 
       each function has a stack frame marked by %ebp, %esp 
               +------------+   |
               | arg 2      |   \
               +------------+    >- previous function's stack frame
               | arg 1      |   /
               +------------+   |
               | ret %eip   |   /
               +============+   
               | saved %ebp |   \
        %ebp-> +------------+   |
               |            |   |
               |   local    |   \
               | variables, |    >- current function's stack frame
               |    etc.    |   /
               |            |   |
               |            |   |
        %esp-> +------------+   /


 */

/*
 * First's argument offset with respect to the frame.  Dependent on
 * optimizations made by the compiler.  The value below is the 
 * non-optimized one. 
 */
#define ARG_OFFSET     (2) 
/*
 * gcc 4.7.2 and -O0: return value is stored in the ebx register.
 */
#define GET_RBX(var)  asm volatile ( "movq %%rbx, %0" : "=r"(var) )
#define SET_RBX(var)  asm volatile ( "movq %0, %%rbx" : :"r"(var) )

/* static void print_stack(void); */
static int n_chr(const char *str, char ch);
static int is_cpp(const char *func_sig);
static char* get_args(char *buf, int len, int n_args, int *frame);

#define MAX_ARGS_TO_LOG	(4)
#define ARG_BUF_LEN	(12*(MAX_ARGS_TO_LOG+1))

EXTERNC void 
__cyg_profile_func_enter(void *func, void *callsite)
{
	printf("enter\n");

    struct timespec ts;			/* timestamp */
    int self = 0;			/* thread identifier */
    char func_buf[MAX_BUF_LEN] = {0};	/* buffer for function signature */
    char site_buf[MAX_BUF_LEN] = {0}; 	/* buffer for callsite signature */
    char arg_buf[ARG_BUF_LEN] = {0}; 	/* buffer for argument values */
    int *frame = NULL;			/* stack frame address; for argument value retrieval */
    int n_args = 0;
 
    clock_gettime(CLOCK_REALTIME, &ts);
    self = syscall(SYS_gettid);
    frame = (int *)__builtin_frame_address(1);
    assert(frame != NULL);
 
    /* resolve called function address to function signature */
    libtrace_translate_addresses (func, func_buf, MAX_BUF_LEN, NULL, 0);

    /* resolve function callsite with respect to program source */
    libtrace_translate_addresses (callsite, NULL, 0, site_buf, MAX_BUF_LEN);
    n_args = n_chr(func_buf, ',') + 1	/* last arg not followed by a comma */; 
    n_args += is_cpp(func_buf);		/* class member functions will have 'this' parameter */
    if (n_args > MAX_ARGS_TO_LOG)
        n_args = MAX_ARGS_TO_LOG;
    get_args(arg_buf, ARG_BUF_LEN, n_args, frame);

    fprintf(fp, "%lld.%.9ld T%d ENTER %s %s [from %s]\n", 
           (long long)ts.tv_sec, ts.tv_nsec, self,
           func_buf, arg_buf, site_buf);
    
    /*print_stack(); */
}



EXTERNC void 
__cyg_profile_func_exit(void *func, void *callsite)
{
    struct timespec ts;			/* timestamp */
    int self = 0;			/* thread identifier */
    char func_buf[MAX_BUF_LEN] = {0};	/* buffer for function signature */
    char arg_buf[ARG_BUF_LEN] = {0}; 	/* buffer for argument values */
    int *frame = NULL;			/* stack frame address; for argument value retrieval */
    int n_args = 0;
    long ret = 0L; 			/* return value */

    GET_RBX(ret);			/* retrieve return value.  Note that the return values will only
					 * predictably be placed in %rbx at the time of cyg_profile_func_exit
					 * if instrumented functions are compiled with optimization -O0. */
    clock_gettime(CLOCK_REALTIME, &ts);
    self = syscall(SYS_gettid);
    frame = (int *)__builtin_frame_address(1);
    assert(frame != NULL);     

    /* resolve called function address to function signature */
    libtrace_translate_addresses (func, func_buf, MAX_BUF_LEN, NULL, 0);
    n_args = n_chr(func_buf, ',') + 1	/* last arg not followed by a comma */; 
    n_args += is_cpp(func_buf);		/* class member functions will have 'this' parameter */
    if (n_args > MAX_ARGS_TO_LOG)
        n_args = MAX_ARGS_TO_LOG;
    get_args(arg_buf, ARG_BUF_LEN, n_args, frame);

    fprintf(fp, "%lld.%9ld T%d EXIT %s %s %ld\n", 
           (long long)ts.tv_sec, ts.tv_nsec, self,
           func_buf, arg_buf, ret);
    
    SET_RBX(ret); 
}



void __init()  __attribute__((constructor));
void 
__init()
{
/*	printf("init\n");*/

    if (!init) {
        char link[MAX_BUF_LEN] = {0};
	char path[MAX_BUF_LEN] = {0};
        pid_t pid = getpid();
        sprintf(link, "/proc/%d/exe", pid);

        if ((readlink(link, path, MAX_BUF_LEN - 1)) == -1) {
            perror("readlink");
            exit(EXIT_FAILURE);
        }

        if (0 != libtrace_init(path, NULL, NULL)) {
            fprintf(stderr, "libtrace_init() failed.");
            exit(EXIT_FAILURE); 
        }

        fp = fopen("/tmp/threadtrace.log", "w");

	/* log program name */
	char *program_name = strrchr(path, '/');
	if (program_name != NULL)
		fprintf(fp, "program_name: %s\n", program_name + 1);
	else
		fprintf(fp, "program_name: %s\n", path);

        init = 1;
    }
}


void  __done()  __attribute__((destructor));
void 
__done()
{
    if (!done) {
        libtrace_close();
        fclose(fp);

        done = 1;
    }
}


/*
static void
print_stack( void )
{
    void *array[6];
    size_t size;
    char **strings;
    size_t i;
  
    size = backtrace (array, 6);
    strings = backtrace_symbols (array, size);
  
    printf ("Obtained %zd stack frames.\n", size);
  
    for (i = 0; i < size; i++)
        printf ("%s\n", strings[i]);
  
    free (strings);
}
*/


/*Number of occurences of 'ch' in 'str'. */
static int
n_chr(const char *str, char ch)
{
    int n = 0;
    while (*str != '\0') {
        if (*str == ch)
            n++;
        str++;
    }
    return n; 
}

/*A not-very-sophisticated function to print arguments. */
/* TODO: Implement address lookups for function pointers as detected from the function signature */
static char *
get_args(char *buf, int len, int n_args, int *frame)
{
    int i; 
    int offset;
    
    memset(buf, 0, len); 
    
    snprintf(buf, len, "("); 
    offset = 1; 
    for (i = 0; i < n_args && offset < len; i++) {
        offset += snprintf(buf + offset, len - offset,
		"%d%s", *(frame + ARG_OFFSET + i),
            	i == (n_args - 1) ? ")" : ", ");
    }
    
    return buf; 
}

static int
is_cpp(const char *func_sig)
{
    if (NULL == strstr(func_sig, "::"))
        return 0;
    return 1; 
}


